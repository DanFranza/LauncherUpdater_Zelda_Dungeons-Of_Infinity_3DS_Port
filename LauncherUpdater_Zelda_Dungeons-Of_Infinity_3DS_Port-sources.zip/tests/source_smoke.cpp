#include "update_source.h"
#include <cassert>
#include <string>
int main() {
    assert(std::string(defaultUpdateUrl()).find("/contents/doi3ds.3dsx?ref=3DS-port") != std::string::npos);
    assert(std::string(ciaUpdateUrl()).find("/contents/doi3ds.cia?ref=3DS-port") != std::string::npos);
    Release release; std::string error;
    std::string json = R"({"type":"file","path":"doi3ds.3dsx","sha":"0123456789abcdef0123456789abcdef01234567","size":1000,"download_url":"https://raw.githubusercontent.com/DanFranza/The-Legend-of-Zelda-Dungeons-of-Infinity-and-Beyond-3DS/3DS-port/doi3ds.3dsx"})";
    assert(parseGitHubFile(json, release, error));
    assert(release.size == 1000 && release.format == GameFormat::ThreeDSX);
    assert(!parseGitHubFile(json, release, error, GameFormat::CIA));
    json.replace(json.find("doi3ds.3dsx"), 12, "doi3ds.cia ");
    assert(!parseGitHubFile(json, release, error));
}
