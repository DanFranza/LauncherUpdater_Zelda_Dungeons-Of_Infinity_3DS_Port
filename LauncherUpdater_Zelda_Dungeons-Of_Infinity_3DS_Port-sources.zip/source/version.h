#pragma once
#define LAUNCHER_VERSION "1.0.2"
