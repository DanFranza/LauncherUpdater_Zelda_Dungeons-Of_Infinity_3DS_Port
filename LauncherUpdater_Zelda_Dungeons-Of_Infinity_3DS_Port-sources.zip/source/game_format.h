#pragma once
#include <cstdint>
#include <string>
enum class GameFormat { ThreeDSX, CIA };
const char* gameFormatCode(GameFormat format);
bool parseGameFormat(const std::string& text,GameFormat& format);
bool validGameCia(const std::string& path);
